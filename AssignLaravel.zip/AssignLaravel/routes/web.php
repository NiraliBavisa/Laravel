<?php

use App\Http\Controllers\StudentsController;
use Illuminate\Support\Facades\Route;

Route::get('/',[StudentsController::class,'index']);
Route::get('/create',[StudentsController::class,'create']);
Route::get('/show/{id}',[StudentsController::class,'show']);
Route::get('/edit/{id}',[StudentsController::class,'edit']);
Route::post('/update/{id}',[StudentsController::class,'update']);
Route::post('/delete/{id}',[StudentsController::class,'delete'])->name('delete');
Route::post('/store',[StudentsController::class,'store']);