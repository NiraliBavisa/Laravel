<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" integrity="sha512-5A8nwdMOWrSz20fDsjczgUidUBR8liPYU+WymTZP1lmY9G6Oc7HlZv156XqnsgNUzTyMefFTcsFH/tnJE/+xBg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<style>
h1 {text-align: center;}
h3 {text-align: center;}
</style>
</head>
<body>
    @extends('master')
    @section('content')
    <h1 class="bg-info">CRUD EXAMPLE</h1>
    <h3>Student Data</h3>
    <div class="container">
    <table class="table table-striped">
    <thead class="table-dark">
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Email</th>
      <th scope="col">Password</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    @foreach ($students as $student)
    <tr>
      <th scope="row">{{$student->id}}</th>
      <td>{{$student->email}}</td>
      <td>{{$student->password}}</td>
      <td class="d-flex justify-content-center gap-2">
        <button class="btn btn-info"><a href="{{URL::to('show',$student->id)}}"><i class="fa fa-user-circle-o" aria-hidden="true"></i></a></button>
        <button class="btn btn-success"><a href="{{URL::to('edit',$student->id)}}"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></button>
        <form action="{{route('delete',$student->id);}}" method="post">@csrf
        <button type="submit" class="btn btn-danger"><a href="{{URL::to('delete',$student->id)}}"><i class="fa fa-trash" aria-hidden="true"></i></a></button>
        </form>
      </td>
    </tr>
    @endforeach
  </tbody>
</table>
    </div>
    @endsection
</body>
</html>